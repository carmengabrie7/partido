package partidos;

import javax.swing.JOptionPane;


public class Partidos {

    
    public static void main(String[] args) {
        // TODO code application logic here
        int ganados,perdidos,empatados;
        double puntajetotal;
        ganados = Integer.parseInt(JOptionPane.showInputDialog("Favor ingresar la cantidad de partidos ganados"));
        perdidos = Integer.parseInt(JOptionPane.showInputDialog("Favor ingresar la cantidad de partidos perdidos"));
        empatados = Integer.parseInt(JOptionPane.showInputDialog("Favor ingresar la cantidad de partidos empatados"));
        
        puntajetotal = (ganados * 3) + (empatados * 1) + (perdidos * 0);
        JOptionPane.showMessageDialog(null, "El puntaje total del equipo es:"+puntajetotal);
        
        
        
    }
    
}
